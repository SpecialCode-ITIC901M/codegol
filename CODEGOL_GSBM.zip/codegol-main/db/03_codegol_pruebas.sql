-- =====================================================================
--  CODEGOL - Escenarios de prueba (ejecutar DESPUÉS del 01 y el 02)
--  Cada bloque dice qué debe pasar. Ejecuta de uno en uno (Ctrl+Enter).
--  Los bloques marcados "DEBE FALLAR" muestran el error esperado.
-- =====================================================================
USE codegol;

-- ── HU-04 esc.3: traslape de cancha ─────────────────────────────────
-- DEBE FALLAR: "Traslape: la cancha ya está ocupada en ese horario"
INSERT INTO partidos (jornada_id, cancha_id, fecha, hora_inicio, hora_fin, equipo_local_id, equipo_visitante_id)
VALUES (3, 1, '2026-11-09', '10:30', '11:30', 2, 3);

-- ── HU-04 esc.3: traslape de equipo (Tigres ya juega a esa hora en otra cancha) ──
-- DEBE FALLAR: "Traslape: un equipo ya juega en ese horario"
INSERT INTO partidos (jornada_id, cancha_id, fecha, hora_inicio, hora_fin, equipo_local_id, equipo_visitante_id)
VALUES (3, 3, '2026-11-09', '10:00', '11:00', 1, 2);

-- ── HU-05 esc.2: cédula bloqueada si el arbitraje no está cubierto ──
-- El partido 3 (Tigres vs Neza, HOY) solo tiene pagado 1 de 2 arbitrajes.
SELECT * FROM v_arbitraje_partido WHERE partido_id IN (3,4);   -- 3 = PENDIENTE (1/2), 4 = CUBIERTO (2/2)
-- DEBE FALLAR: "Arbitraje pendiente de pago: no se puede abrir la cédula"
CALL sp_iniciar_cedula(3);

-- Se cobra el arbitraje que falta (el trigger emite el recibo) y ya se puede abrir:
INSERT INTO pagos (equipo_id, concepto, partido_id, monto, estado, fecha_pago, cobrado_por)
VALUES (3, 'ARBITRAJE', 3, 150, 'CUBIERTO', NOW(), 1);
SELECT folio FROM recibos ORDER BY id DESC LIMIT 1;            -- nuevo folio CG-0000xx
CALL sp_iniciar_cedula(3);                                     -- OK: partido 3 -> EN_CURSO

-- ── HU-01 esc.3: un jugador suspendido no puede alinear ─────────────
-- Joel Campos (id 12, Neza) tiene roja directa: el pase de lista queda SUSPENDIDO aunque la huella coincida.
INSERT INTO pase_lista (partido_id, jugador_id, equipo_id, resultado, metodo, tiempo_ms, validado_por)
VALUES (3, 12, 3, 'AUTORIZADO', 'HUELLA', 1200, 3);
INSERT INTO pase_lista (partido_id, jugador_id, equipo_id, resultado, metodo, tiempo_ms, validado_por)
VALUES (3, 11, 3, 'AUTORIZADO', 'HUELLA', 1100, 3);
SELECT jugador_id, resultado FROM pase_lista WHERE partido_id = 3;   -- 12 = SUSPENDIDO, 11 = AUTORIZADO

-- ── HU-02 esc.2: captura de eventos (solo con el partido EN_CURSO) ──
INSERT INTO eventos_partido (partido_id, equipo_id, jugador_id, tipo, minuto) VALUES
 (3,1,4,'GOL',10),(3,1,3,'AMARILLA',22),(3,3,14,'GOL',30),(3,1,4,'GOL',51),(3,1,3,'AMARILLA',58);
-- DEBE FALLAR en el partido 5 (aún PROGRAMADO): "La cédula no está abierta"
INSERT INTO eventos_partido (partido_id, equipo_id, jugador_id, tipo, minuto) VALUES (5,1,4,'GOL',5);

-- DEBE FALLAR: "El jugador no pertenece al equipo del evento" (Diego es de Tigres, no de Neza)
INSERT INTO eventos_partido (partido_id, equipo_id, jugador_id, tipo, minuto) VALUES (3,3,3,'GOL',60);

-- ── HU-02 esc.3 + HU-03: cierre de cédula, puntos, DG y suspensiones ──
CALL sp_cerrar_cedula(3);
SELECT posicion, equipo, pj, pg, pe, pp, gf, gc, dg, pts FROM v_tabla_general WHERE torneo_id = 1 ORDER BY posicion;
-- Esperado: Tigres 6 pts (2-1 a Águilas y 2-1 a Neza), DG +2. Neza 0 pts.
SELECT jugador, goles FROM v_goleadores WHERE torneo_id = 1 ORDER BY goles DESC;   -- Raúl Pineda 4 goles

-- ── HU-03 esc.3: suspensión automática ──
-- Diego Núñez (Tigres #8) llegó a 3 amarillas (1 en J1 + 2 hoy) = límite del torneo -> SUSPENDIDO por acumulación.
-- Joel Campos (Neza) ya cumplió su partido de la roja y desaparece de la lista.
SELECT jugador, equipo, motivo, partidos_restantes FROM v_jugadores_suspendidos;

-- Segundo partido de hoy (Águilas vs Halcones, arbitraje ya cubierto por los dos equipos)
CALL sp_iniciar_cedula(4);
INSERT INTO eventos_partido (partido_id, equipo_id, jugador_id, tipo, minuto) VALUES
 (4,2,8,'AMARILLA',15),(4,4,19,'GOL',40),(4,2,9,'GOL',44),(4,4,20,'GOL',70);
CALL sp_cerrar_cedula(4);
SELECT posicion, equipo, pj, pts, dg FROM v_tabla_general WHERE torneo_id = 1 ORDER BY posicion;

-- ── HU-05 esc.1: cobro de inscripción -> equipo ACTIVO + recibo ──
SELECT e.nombre, i.estado FROM inscripciones i JOIN equipos e ON e.id = i.equipo_id WHERE i.torneo_id = 2;  -- Las Guerreras y Neza Queens: PENDIENTE_PAGO
INSERT INTO pagos (equipo_id, concepto, inscripcion_id, monto, metodo_pago, estado, fecha_pago, cobrado_por)
VALUES (6, 'INSCRIPCION', 6, 1200, 'TARJETA', 'CUBIERTO', NOW(), 1);
SELECT e.nombre, i.estado FROM inscripciones i JOIN equipos e ON e.id = i.equipo_id WHERE i.torneo_id = 2;  -- Las Guerreras: ACTIVO
SELECT * FROM tabla_posiciones WHERE torneo_id = 2;                                                          -- ya tiene su renglón

-- ── HU-05 esc.3: reporte financiero por fechas y concepto ──
SELECT concepto, COUNT(*) pagos, SUM(monto) total FROM pagos
WHERE estado = 'CUBIERTO' AND fecha_pago BETWEEN '2026-10-01' AND '2026-11-30' GROUP BY concepto;
SELECT * FROM v_ingresos ORDER BY dia;

-- ── Usuarios: el username distingue mayúsculas ──
SELECT username FROM usuarios WHERE username = 'admin';   -- 1 fila
SELECT username FROM usuarios WHERE username = 'Admin';   -- 0 filas
-- DEBE FALLAR (formato): usuario con espacios
INSERT INTO usuarios (username, nombre_completo, email, password_hash, rol) VALUES ('mal usuario', 'Prueba', 'x@x.com', 'x', 'ROLE_ADMIN');
-- Se permite "Admin" porque es distinto de "admin":
INSERT INTO usuarios (username, nombre_completo, email, password_hash, rol) VALUES ('Admin', 'Otro Admin', 'otro@codegol.mx', 'x', 'ROLE_ADMIN');
-- DEBE FALLAR: mismo usuario exacto repetido
INSERT INTO usuarios (username, nombre_completo, email, password_hash, rol) VALUES ('Admin', 'Otro', 'otro2@codegol.mx', 'x', 'ROLE_ADMIN');
