export { default } from './Equipos.jsx'
