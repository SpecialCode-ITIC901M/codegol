# Contrato de API — CODEGOL (front React ↔ backend Spring Boot)

Base: `/api` (el proxy de Vite apunta a `http://localhost:8080`). JSON, `Authorization: Bearer <token>` en todo
salvo `auth/*` y los endpoints públicos (🌐: el portal no pide login). Errores: `{ "message": "..." }` con
400 (validación), 401 (sin sesión: el front manda al login), 409 (conflicto: traslape, duplicado).
Fechas `YYYY-MM-DD`, horas `HH:mm`, fecha-hora `YYYY-MM-DDTHH:mm:ss`.
Roles: `ROLE_ADMIN`, `ROLE_ARBITRO`, `ROLE_MESA_CONTROL`.
El login debe devolver `{ token, username, nombreCompleto, email, rol }` (el front usa `rol` para limitar el panel web a ADMIN).

| Método y ruta | Cuerpo / query | Respuesta |
|---|---|---|
| POST `auth/login` | `{username,password}` | `{token,username,nombreCompleto,email,rol}` |
| POST `auth/registro` | `{username,email,nombreCompleto,password,rol}` | 201 · 409 si ya existe |
| GET 🌐 `torneos` | — | `[{id,nombre,descripcion,categoria:{id,nombre},fechaInicio,fechaFin,estado,cuotaInscripcion,cuotaArbitraje,limiteAmarillas,puntosVictoria,puntosEmpate}]` |
| GET 🌐 `torneos/{id}` | — | un torneo (mismo formato) |
| POST `torneos` | `{nombre,descripcion,categoriaId,fechaInicio,fechaFin,estado,cuotaInscripcion,cuotaArbitraje,limiteAmarillas}` | torneo creado |
| PUT `torneos/{id}` | campos a cambiar, ej. `{estado}` | torneo. Estados: `EN_INSCRIPCION, EN_PROGRESO, FINALIZADO, CANCELADO` **(nuevo)** |
| GET / POST `torneos/categorias` | `{nombre,descripcion,activa}` | categorías |
| GET `equipos` | — | `[{id,nombre,delegado,telefono,logoUrl}]` |
| GET 🌐 `equipos/torneo/{torneoId}` | — | equipos + `{torneoId,torneoNombre,pagoInscripcionCubierto}` (vista `v_equipos_torneo`) |
| POST `equipos` | `{nombre,delegado,telefono,logoUrl,torneoId,pagoInscripcionCubierto}` | equipo; crea la inscripción |
| PUT `equipos/{id}` | `{nombre,delegado,telefono,logoUrl}` | equipo · 409 si el nombre ya existe **(nuevo)** |
| GET `jugadores?equipoId=` | — | `[{id,equipoId,equipo,nombre,apellidos,posicion,dorsal,curp,fotoUrl,huella}]` (`huella`=true si hay plantilla) |
| POST / PUT / DELETE `jugadores[/id]` | `{nombre,apellidos,equipoId,posicion,dorsal,curp,fotoUrl}` | jugador · 409 dorsal/CURP repetidos. `fotoUrl` es **nuevo** |
| GET `canchas` · GET `usuarios/arbitros` | — | `[{id,nombre}]` · usuarios ARBITRO y MESA_CONTROL |
| GET 🌐 `partidos?torneoId=` | — | `[{id,torneoId,torneo,jornada,fecha,horaInicio,horaFin,canchaId,cancha,localId,local,visitanteId,visitante,golesLocal,golesVisitante,estado,arbitroId,arbitro,arbitrajeCubierto,equiposPagados}]` |
| POST `partidos` · PUT `partidos/{id}` | partido / cambios (`fecha,horaInicio,horaFin,canchaId,arbitroId`) | **409** `Traslape: …` si cancha o equipo ocupados |
| DELETE `partidos/{id}` | — | 204 |
| POST `torneos/{id}/calendario` | `{fechaInicio,diasEntreJornadas,horarios[],duracionMin,canchaIds[],dobleVuelta}` | `{creados,sinLugar:[{jornada,localId,visitanteId}]}` · 409 si ya hay partidos jugados |
| DELETE `torneos/{id}/calendario` | — | 204 (quita solo los PROGRAMADO) |
| GET `partidos/{id}/cedula` | — | **(nuevo)** `{partido:{…como arriba}, pases:[{jugadorId,jugador,dorsal,fotoUrl,equipoId,equipo,resultado,metodo,tiempoMs,validadoEn}], eventos:[{id,tipo,minuto,jugadorId,jugador,dorsal,equipoId,equipo}], plantillas:[{equipoId,equipo,jugadores:[{jugadorId,jugador,dorsal,huella,suspendido}]}]}` |
| GET 🌐 `torneos/{id}/posiciones` | — | `[{posicion,equipoId,equipo,logoUrl,pj,pg,pe,pp,gf,gc,dg,pts}]` (vista `v_tabla_general`) |
| GET 🌐 `torneos/{id}/goleadores` | — | `[{posicion,jugadorId,jugador,equipo,goles}]` |
| GET `torneos/{id}/suspensiones` | — | `[{jugadorId,jugador,equipo,motivo,partidosRestantes}]` |
| GET `pagos?desde=&hasta=&concepto=` | — | `[{id,folio,equipoId,equipo,torneoId,torneo,partidoId,concepto,descripcion,monto,metodo,estado,fechaPago}]` solo CUBIERTO |
| POST `pagos` | `{equipoId,torneoId,concepto,partidoId,monto,metodo,descripcion}` | pago con `folio`. INSCRIPCION activa la inscripción · 409 si el equipo ya pagó ese arbitraje |
| GET `pagos/{id}` | — | recibo |
| GET `usuarios` | — | **(nuevo)** `[{id,username,nombreCompleto,email,rol}]` solo ADMIN (pantalla Configuración › Usuarios y permisos) |
| PUT `usuarios/{id}/rol` | `{rol}` (`ROLE_ADMIN`\|`ROLE_ARBITRO`\|`ROLE_MESA_CONTROL`) | **(nuevo)** usuario actualizado · 409 si dejaría al sistema sin administradores. Equivale a `UPDATE usuarios SET rol=? WHERE id=?` |

Notas para el backend
* `pagos.monto` acepta 0 (inscripción o arbitraje gratis si el torneo tiene cuota 0), igual que la BD (`CHECK monto >= 0`). Una MULTA siempre lleva monto > 0.
* El front manda `apellidos` en un solo campo y `metodo`; la BD los separa (`apellido_paterno/materno`) y usa `metodo_pago`: mapear en el DTO.
* Cerrar cédula = `CALL sp_cerrar_cedula(partidoId)`; abrirla = `sp_iniciar_cedula` (rechaza si el arbitraje no está cubierto). Eso lo usa la APK; el panel web solo consulta.
* Si un endpoint no existe (404/501/5xx genérico) el front usa su base demo local y muestra un aviso azul.
