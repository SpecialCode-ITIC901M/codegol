# Trazabilidad: Especificación de Requerimientos / Product Backlog → CODEGOL

Estado de cada historia de usuario en lo que corresponde al **Frontend Web (React)** y a la **Base de datos (MySQL/MariaDB)**.
La APK (Kotlin) y el backend (Spring Boot) son otras partes del equipo (Sprint 2 en adelante).

| HU | Escenario (documento) | Front web | Base de datos |
|---|---|---|---|
| **HU-01** Biometría | Registro de huella al dar de alta | Alta de jugador con foto, CURP y estado "huella registrada/pendiente" (`/admin/jugadores`). La captura con el lector se hace en la APK | `huellas_biometricas` (plantilla única por jugador) |
| | Pase de lista < 3 s con foto y datos | Cédula del partido: pase de lista por equipo con tiempo de validación (`/admin/partidos/:id`) | `pase_lista` (`tiempo_ms`) |
| | Bloqueo por huella no coincidente o suspensión | Estados "Huella no coincide" / "Suspendido: no puede alinear" | Trigger `trg_pase_lista_suspension` |
| **HU-02** Cédula | Partidos asignados a su cancha y fecha | Calendario, asignación de árbitro (`/admin/arbitros`); el filtro por cancha/fecha de la APK usa `v_calendario` | `partidos.arbitro_id`, `v_calendario` |
| | Registro rápido de goles/tarjetas | Visualización en vivo de eventos (la captura es en la APK) | `eventos_partido` (+ `sync_uuid` para offline), trigger `trg_eventos_validar` |
| | Cierre de cédula y sincronización | Cédula cerrada muestra marcador final | `sp_cerrar_cedula` |
| **HU-03** Estadísticas | 3 pts victoria / 1 empate | Tabla general (`/admin/estadisticas` y portal) | `sp_recalcular_posicion`, `tabla_posiciones` |
| | Recálculo de diferencia de goles | Columna DG, portal se refresca solo cada 30 s | columna generada `dg` |
| | Suspensión automática por tarjetas | Pestaña "Sanciones" y chip "Suspendido" en jugadores | `suspensiones`, `v_jugadores_suspendidos`; límite configurable por torneo |
| **HU-04** Torneos | Crear torneo y categorías (varonil, femenil, libre) | `/admin/torneos`: categorías, torneo, inscripción de equipos, cambio de estado | `categorias`, `torneos`, `inscripciones` |
| | Generar calendario automático | Botón "Generar calendario" (todos contra todos, canchas y horarios) | `jornadas`, `partidos` |
| | Detección de traslapes | Aviso y bloqueo al guardar (cancha o equipo ocupado) | Triggers `trg_partidos_traslape_*` + índice único |
| **HU-05** Finanzas | Cobro de inscripción, recibo y estado Inscrito/Activo | `/admin/finanzas` → "Registrar cobro" + recibo imprimible | `pagos`, `recibos` (folio), trigger de activación |
| | Cédula solo si el arbitraje está cubierto | "Arbitrajes por cobrar" y candado en la cédula | `v_arbitraje_partido`, `sp_iniciar_cedula` |
| | Reporte por fechas (inscripciones, arbitrajes, multas) | "Reporte de ingresos" con filtro de fechas y CSV | `v_ingresos` |
| **HU-06** Portal público | Navegar sin login por torneo y categoría | Portal en `/` y `/consulta-publica`: filtro de categoría + torneo | `v_tabla_general` |
| | Calendario por jornada con fecha, hora y cancha | Pestaña "Calendario" | `v_calendario` |
| | Ranking de goleadores | Pestaña "Goleadores" | `v_goleadores` |

Actores (1.3): Administrador General (panel web), Árbitro / Mesa de control (APK; si entran al panel web ven un aviso), Jugador / Aficionado (portal público, sin cuenta).

## Elementos del proyecto que NO vienen literalmente en la documentación
Conviene saberlo por si la profesora pregunta (ninguno contradice la documentación):
* **Modo demostración** (datos en el navegador cuando no hay backend; usuario `123` / contraseña `123`). Es solo para desarrollo.
* **Burbuja de ayuda "¿Te ayudo?"**, galería de fotos y animación de la portada.
* **Dashboard** con métricas, **Configuración** y **Notificaciones** del panel.
* **Cédula del partido en el web**: es una vista de consulta para el administrador (la captura real es de la APK).
* **Cambiar el estado del torneo** (En inscripción / En progreso / Finalizado / Cancelado) y **editar equipos**.
